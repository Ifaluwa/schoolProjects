#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include "answer11.c"

int main(int argc, char * * argv)
{	
	//STAGE '0'
	if(argc != 3) return EXIT_FAILURE;
	char *state = argv[2];
	char *movelist = argv[3];
        int n_moves = atoi(argv[3]);
	if(!isValidState(state)) return EXIT_FAILURE;
	if(!isValidMoveList(movelist)) return EXIT_FAILURE;
	if(argv[1] != "1" || arv[1] != "2" || argv[1] != "3") return EXIT_FAILURE;
       
	//STAGE 1
	if(!isValidState(state)) return EXIT_FAILURE;
        if(!isValidMoveList(movelist)) return EXIT_FAILURE;
	processMovelist(state, movelist);	
	MoveTree *root = generateAll(state, n_moves);
	MoveTree_print(root);
	MoveTree_destroy(root);
	return EXIT_SUCCESS;

	//STAGE 2
	if(!isValidState(state)) return EXIT_FAILURE;
	if(movelist != 0 || movelist != 1 || movelist != 2 || movelist != 3 || movelist != 4 || movelist != 5 || movelist != 6 || movelist != 7 || movelist != 8 || movelist != 9)
	return EXIT_FAILURE;
	
}
