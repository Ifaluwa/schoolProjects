#include<stdio.h>
#include<stdlib.h>
#include<libgen.h>
#include<string.h>

#include "answer05.h"
#define TRUE 1
#define FALSE 0

Image * Image_load(const char * filename)
{
	ImageHeader header;
	size_t read;
	Image *tmp_im = NULL;;
	Image *im = NULL;	

	//OPEN FILE	
	FILE * fp = fopen(filename, "rb");
	int err = fp == NULL;
	if (err)fprintf(stderr, "unable to open file %s!\n", filename); return NULL;
	

	//READ THE HEADER	
	if(!err)
	{
		read = fread(&header, sizeof(ImageHeader), 1, fp);
		err = (read != 1) || (header.magic_number != ECE264_IMAGE_MAGIC_NUMBER) || (header.width == 0) || (header.height == 0) || (header.comment_len == 0);
		if(err)fprintf(stderr, "corrupt header\n"); return NULL;
	}
	
	//ALLOCATE MEMORY
	if(!err)
	{
	tmp_im = malloc(sizeof(Image));
	err = tmp_im == NULL;
	if(err) fprintf(stderr, "unable to allocate memory\n");	return NULL;
	}
	

	//ALLOCATE MEMORY FOR THE COMMENTS AND PIXELS
	if(!err)
	{
	tmp_im->width = header.width;
	tmp_im->height = header.height;
	tmp_im->comment = malloc(sizeof(char) * header.comment_len);	
	tmp_im->data = malloc(sizeof(char) * header.width * header.height);
	err = (tmp_im->comment == NULL) || (tmp_im->data == NULL);
	if(err)fprintf(stderr, "Unable to allocate memory\n"); return NULL;
	}

	//READ THE COMMENT
 	if(!err)
	{
	read = fread(tmp_im->comment, sizeof(char), header.comment_len, fp);
	err = (read != header.comment_len) || (tmp_im->comment[header.comment_len - 1] != '\0');
	if(err) fprintf(stderr, "NOT ENOUGH COMMENTS!\n"); return NULL;
	}

	//READ THE PIXELS
	if(!err)
	{
	read = fread(tmp_im->data, sizeof(char), (header.width * header.height), fp);
	err = (read != (header.width * header.height));
	if(err)fprintf(stderr, "Unable to Read Pixels!\n");return NULL;
	}
	
	//MAKE SURE END OF FILE
	if(!err)
	{
	fgetc(fp);
	err = !feof(fp);
	if(err) fprintf(stderr, "Not end of file! Corrupt File\n"); return NULL;
	}

	

	//CLOSE THE FILE	
	if(fp) fclose(fp);
	return tmp_im;
}
int Image_save(const char * filename, Image * image)
{
    FILE * fp = NULL;
    size_t written = 0;
        fp = fopen(filename, "wb");
	if(fp == NULL) return FALSE;

 	ImageHeader hdr;
	hdr.magic_number = ECE264_IMAGE_MAGIC_NUMBER;
	hdr.width = image->width;
	hdr.height = image->height;
	hdr.comment_len = strlen(image->comment) + 1;

	//write the header
	written = fwrite(&hdr, sizeof(ImageHeader), 1, fp);
	fprintf(fp, "%s%c", image->comment, '\0');

	//write the comment
	written = fwrite(image->comment, sizeof(char), hdr.comment_len, fp);
	
	//read the pixels
	written = fwrite(image->data, sizeof(char), (hdr.width * hdr.height), fp);

	/*int i;	
	for(i = 1; i < (image->width * image->height); i++)
	{
	written = fwrite(&hdr, sizeof(image->data), (image->width * image->height), fp);
	fprintf(fp, "%c",image->data[i]);
	} */      
	if(fp) fclose(fp);
         return TRUE;                      

}
void Image_free(Image * image)
{
	if(image)
	{
	free (image->data);
	free (image->comment);
	free (image);
	}
}
void linearNormalization(int width, int height, uint8_t * intensity)
{
	int i = 0;
	uint8_t min = intensity[i];
	uint8_t max = intensity[i];

	for(i = 1; i < (width * height); i++)
	{
	if(intensity[i] < min)
	{
		min = intensity[i];
	}

	if(intensity[i] > max)
	{
		max = intensity[i];
	}
	}

	for(i = 0; i < (width * height); i++)
	{
	intensity[i] = (intensity[i] - min) * 255.0 / (max - min);
	}
}
